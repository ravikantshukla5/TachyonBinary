#!/usr/bin/env bash

cd /tachyon
./bin/tachyon-mount.sh SudoMount
