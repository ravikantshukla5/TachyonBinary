#!/usr/bin/env bash

rsync -avz TachyonMaster:/mesos/* /mesos
