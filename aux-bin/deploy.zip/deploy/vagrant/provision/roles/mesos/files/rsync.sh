#!/usr/bin/env bash

rsync -avz AlluxioMaster:/mesos/* /mesos
