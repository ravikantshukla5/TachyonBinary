#!/usr/bin/env bash

cp /vagrant/files/workers /alluxio/conf/workers
