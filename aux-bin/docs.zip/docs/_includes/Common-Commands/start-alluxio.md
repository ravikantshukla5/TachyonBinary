```bash
$ ./bin/alluxio format
$ ./bin/alluxio-start.sh local
```
