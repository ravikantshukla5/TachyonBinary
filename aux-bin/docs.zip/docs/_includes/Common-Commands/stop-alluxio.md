```bash
$ ./bin/alluxio-stop.sh all
```
