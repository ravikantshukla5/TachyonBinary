```bash
$ cp conf/alluxio-env.sh.template conf/alluxio-env.sh
```
