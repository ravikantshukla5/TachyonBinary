```bash
$ ./bin/alluxio runTests
```
