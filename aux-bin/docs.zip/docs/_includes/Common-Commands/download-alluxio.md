```bash
$ wget http://alluxio.org/downloads/files/{{site.ALLUXIO_RELEASED_VERSION}}/alluxio-{{site.ALLUXIO_RELEASED_VERSION}}-bin.tar.gz
$ tar xvfz alluxio-{{site.ALLUXIO_RELEASED_VERSION}}-bin.tar.gz
```
