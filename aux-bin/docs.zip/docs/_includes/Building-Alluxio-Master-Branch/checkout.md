```bash
$ git clone git://github.com/alluxio/alluxio.git
$ cd alluxio
$ mvn install
```
