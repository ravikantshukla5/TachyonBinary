```bash
$ sudo launchctl limit maxfiles 16384 16384
$ sudo launchctl limit maxproc 2048 2048
```
