```bash
$ cp conf/alluxio-env.sh.template conf/alluxio-env.sh
$ ./bin/alluxio format
$ ./bin/alluxio-start.sh local
```
