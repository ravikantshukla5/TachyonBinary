```bash
$ mvn test
```
