```bash
Not Specified # [Default] Tests against local file system
hdfsTest      # Tests against HDFS minicluster
glusterfsTest # Tests against GlusterFS
s3Test        # Tests against Amazon S3 (requires a real s3 bucket)
ossTest       # Tests against Aliyun OSS (requires a real oss bucket)
```
