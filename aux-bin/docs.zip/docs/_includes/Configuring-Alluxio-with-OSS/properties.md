    # Config the OSS credentials
    fs.oss.accessKeyId=<OSS_ACCESS_KEY_ID>
    fs.oss.accessKeySecret=<OSS_SECRET_ACCESS_KEY>
    fs.oss.endpoint=<OSS_ENDPOINT>
