    $ java -Xmx3g -Dfs.oss.accessKeyId=<OSS_ACCESS_KEY_ID> -Dfs.oss.accessKeySecret=<OSS_SECRET_ACCESS_KEY> -Dfs.oss.endpoint=<OSS_ENDPOINT> -cp my_application.jar com.MyApplicationClass myArgs
