```bash
$ ./bin/alluxio copyDir <dirname>
```
