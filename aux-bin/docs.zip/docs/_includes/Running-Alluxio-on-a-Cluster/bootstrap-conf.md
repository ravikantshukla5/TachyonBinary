```bash
$ cd alluxio
$ ./bin/alluxio bootstrap-conf <alluxio_master_hostname>
```
