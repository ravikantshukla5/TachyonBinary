```bash
$ cd alluxio
$ ./bin/alluxio format
$ ./bin/alluxio-start.sh # use the right parameters here. e.g. all Mount
# Notice: the Mount and SudoMount parameters will format the existing RamFS.
```
