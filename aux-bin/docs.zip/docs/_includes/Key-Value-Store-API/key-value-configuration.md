<table class="table table-striped">
<tr><th>Parameter</th><th>Default Value</th><th>Description</th></tr>
<tr>
  <td>alluxio.keyvalue.enabled</td>
  <td>false</td>
  <td>
  Whether the keyvalue interface is enabled.
  </td>
</tr>
<tr>
  <td>alluxio.keyvalue.partition.size.bytes.max</td>
  <td>512MB
  <td>
  Maximum size of each partition.
  </td>
</tr>
</table>