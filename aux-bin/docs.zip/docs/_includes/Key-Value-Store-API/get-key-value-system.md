```java
KeyValueSystem kvs = KeyValueSystem.Factory().create();
```
