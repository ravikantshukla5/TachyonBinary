```java
bool mount(String alluxioPath, String ufsPath);
bool unmount(String alluxioPath);
```
