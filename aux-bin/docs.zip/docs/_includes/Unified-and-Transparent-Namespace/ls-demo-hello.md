```bash
$ ${ALLUXIO_HOME}/bin/alluxio fs ls /demo/hello
... # should contain /demo/hello
```
