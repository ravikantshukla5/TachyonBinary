```bash
$ cd /tmp
$ mkdir alluxio-demo
$ touch alluxio-demo/hello
```
