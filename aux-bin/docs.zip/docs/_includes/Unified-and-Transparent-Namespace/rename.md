```bash
$ ${ALLUXIO_HOME}/bin/alluxio fs mv /demo/hello2 /demo/world
> Renamed /demo/hello2 to /demo/world
$ ls /tmp/alluxio-demo
> hello world
```
