```bash
$ ${ALLUXIO_HOME}/bin/alluxio fs rm /demo/world
> /demo/world has been removed
$ ls /tmp/alluxio-demo
> hello
```
