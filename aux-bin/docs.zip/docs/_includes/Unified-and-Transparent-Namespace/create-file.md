```bash
$ ${ALLUXIO_HOME}/bin/alluxio fs touch /demo/hello2
> /demo/hello2 has been created
$ ls /tmp/alluxio-demo
> hello hello2
```
