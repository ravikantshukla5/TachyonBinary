```bash
$ brew install autoconf automake libtool pkg-config libevent
```
