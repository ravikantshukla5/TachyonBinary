```bash
$ sudo port install boost
```
