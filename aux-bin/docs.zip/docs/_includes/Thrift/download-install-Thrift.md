```bash
$ wget 'https://github.com/apache/thrift/archive/0.9.2.tar.gz'
$ tar zxvf 0.9.2
$ cd thrift-0.9.2/
$ ./bootstrap.sh
$ ./configure --enable-libs=no
$ make
$ sudo make install
```
