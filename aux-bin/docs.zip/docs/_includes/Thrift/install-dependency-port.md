```bash
$ sudo port install flex, bison, autoconf automake libtool pkgconfig libevent
```
