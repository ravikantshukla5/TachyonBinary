```bash
$ sudo apt-get -t lenny-backports install automake libboost-test-dev
```
