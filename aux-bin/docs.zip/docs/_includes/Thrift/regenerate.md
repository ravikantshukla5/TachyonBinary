```bash
    $ ./bin/alluxio thriftGen
```
