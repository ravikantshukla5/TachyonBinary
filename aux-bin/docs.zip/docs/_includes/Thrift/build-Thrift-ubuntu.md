```bash
$ ./configure --with-boost=/usr/local
$ make
$ make install
```
