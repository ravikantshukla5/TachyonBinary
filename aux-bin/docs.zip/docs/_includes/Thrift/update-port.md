```bash
$ sudo port selfupdate
```
