```bash
$ brew install boost
```
