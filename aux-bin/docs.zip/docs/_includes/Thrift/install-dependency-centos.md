```bash
$ sudo yum install automake libtool flex bison pkgconfig gcc-c++ make
```
