```bash
$ ./bin/alluxio fs copyFromLocal LICENSE /wordcount/input.txt
```
