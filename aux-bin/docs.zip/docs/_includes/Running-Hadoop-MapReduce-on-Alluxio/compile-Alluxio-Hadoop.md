```bash
$ mvn install -Dhadoop.version=<YOUR_HADOOP_VERSION>
```
