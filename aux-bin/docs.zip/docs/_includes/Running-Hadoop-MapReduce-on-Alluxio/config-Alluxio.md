```bash
export ALLUXIO_UNDERFS_ADDRESS=hdfs://localhost:9000
```
