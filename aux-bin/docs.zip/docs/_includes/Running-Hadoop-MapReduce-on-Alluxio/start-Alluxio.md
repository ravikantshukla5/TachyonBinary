```bash
$ ./bin/alluxio-stop.sh all
$ ./bin/alluxio-start.sh local
```
