```bash
$ mvn compile findbugs:findbugs
```
