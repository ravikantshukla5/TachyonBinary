```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public MyClass {

  private static final Logger LOG = LoggerFactory.getLogger(Constants.LOGGER_TYPE);

    public void someMethod() {
      LOG.info("Hello world");
    }
}
```
