```bash
$ mvn checkstyle:checkstyle
```
