```bash
$ mvn -Declipse.workspace="your Eclipse Workspace" eclipse:configure-workspace
```
