```bash
$ mvn clean package
```
