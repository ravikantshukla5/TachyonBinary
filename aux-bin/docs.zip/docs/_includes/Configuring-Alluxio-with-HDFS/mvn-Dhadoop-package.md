```bash
$ mvn -Dhadoop.version=2.6.0 clean package
```
