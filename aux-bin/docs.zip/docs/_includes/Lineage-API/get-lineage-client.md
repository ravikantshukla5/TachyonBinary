```java
AlluxioLineage tl = AlluxioLineage.get();
```
