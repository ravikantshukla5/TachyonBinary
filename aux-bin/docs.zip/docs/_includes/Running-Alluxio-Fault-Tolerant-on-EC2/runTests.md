```bash
$ /alluxio/bin/alluxio runTests
```
