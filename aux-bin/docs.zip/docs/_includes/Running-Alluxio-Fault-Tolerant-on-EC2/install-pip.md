```bash
$ sudo pip install -r pip-req.txt
```
