```bash
$ vagrant ssh <node name>
```
