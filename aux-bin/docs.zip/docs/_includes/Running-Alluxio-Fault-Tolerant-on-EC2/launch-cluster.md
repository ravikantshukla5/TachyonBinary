```bash
$ ./create <number of machines> aws
```
