```bash
$ cp deploy/vagrant/conf/ec2.yml.template deploy/vagrant/conf/ec2.yml
```
