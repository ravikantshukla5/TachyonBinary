```bash
$ ./destroy
```
