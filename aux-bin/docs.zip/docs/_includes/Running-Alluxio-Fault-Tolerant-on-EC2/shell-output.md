    >>> Master public IP for Alluxio is xxx, visit xxx:19999 for Alluxio web UI<<<
    >>> Master public IP for other softwares is xxx <<<
    >>> visit default port of the web UI of what you deployed <<<
