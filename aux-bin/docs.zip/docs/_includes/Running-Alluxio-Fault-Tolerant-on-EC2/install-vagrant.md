```bash
$ sudo bash bin/install.sh
```
