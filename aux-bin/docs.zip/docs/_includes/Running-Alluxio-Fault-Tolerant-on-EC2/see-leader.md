```bash
$ ls /leader
```
