```bash
$ jps | grep AlluxioMaster
```
