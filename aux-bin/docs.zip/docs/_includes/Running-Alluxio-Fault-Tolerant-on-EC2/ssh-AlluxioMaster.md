```bash
$ vagrant ssh AlluxioMaster
```
