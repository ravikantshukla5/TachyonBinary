```bash
$ /zookeeper/bin/zkCli.sh
```
