```bash
$ kill -9 <leader pid found via the above command>
```
