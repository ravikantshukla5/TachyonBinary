```bash
$ ssh AlluxioWorker1
```
