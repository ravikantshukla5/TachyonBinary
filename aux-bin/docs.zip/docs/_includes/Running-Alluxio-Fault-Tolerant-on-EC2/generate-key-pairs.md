```bash
$ chmod 400 <your key pair>.pem
```
