```bash
$ ./bin/alluxio runTest Basic CACHE THROUGH
```
