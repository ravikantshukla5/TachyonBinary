```bash
$ tar zxvf jdk-7u<version>-linux-x64.tar.gz
```
