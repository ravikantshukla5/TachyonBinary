```bash
$ brew install protobuf
```
