```bash
$ bin/alluxio protoGen
```
