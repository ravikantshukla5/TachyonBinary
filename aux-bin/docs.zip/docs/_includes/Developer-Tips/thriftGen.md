```bash
$ bin/alluxio thriftGen
```
