```bash
$ brew install thrift
```
