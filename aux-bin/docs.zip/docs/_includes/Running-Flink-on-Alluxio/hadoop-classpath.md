```bash
export HADOOP_CLASSPATH=/pathToAlluxio/core/client/target/alluxio-core-client-{{site.ALLUXIO_RELEASED_VERSION}}-jar-with-dependencies.jar
```
