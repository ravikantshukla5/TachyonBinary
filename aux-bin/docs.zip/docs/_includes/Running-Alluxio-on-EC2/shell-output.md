    >>> AlluxioMaster public IP is xxx, visit xxx:19999 for Alluxio web UI<<<
    >>> visit default port of the web UI of what you deployed <<<
