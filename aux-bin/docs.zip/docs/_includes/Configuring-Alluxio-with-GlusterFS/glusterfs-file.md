    /alluxio_vol/default_tests_files/BasicFile_STORE_SYNC_PERSIST
