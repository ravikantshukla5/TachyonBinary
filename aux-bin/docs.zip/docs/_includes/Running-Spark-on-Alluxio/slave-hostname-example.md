```bash
$ $SPARK_HOME/sbin/start-slave.sh -h simple30 spark://simple27:7077
```
