```bash
$ hadoop fs -put -f foo hdfs://localhost:9000/foo
```
