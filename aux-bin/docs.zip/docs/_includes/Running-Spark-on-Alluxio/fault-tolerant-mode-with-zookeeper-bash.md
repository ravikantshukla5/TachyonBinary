```bash
export SPARK_JAVA_OPTS="
  -Dalluxio.zookeeper.address=zookeeperHost1:2181,zookeeperHost2:2181 \
  -Dalluxio.zookeeper.enabled=true \
  $SPARK_JAVA_OPTS
"
```
