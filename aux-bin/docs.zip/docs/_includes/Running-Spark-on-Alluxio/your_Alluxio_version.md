```xml
<dependency>
  <groupId>org.alluxio</groupId>
  <artifactId>alluxio-core-client</artifactId>
  <version>your_alluxio_version</version>
  ...
</dependency>
```
