```bash
SPARK_LOCAL_HOSTNAME=simple30
```
