```bash
$ $SPARK_HOME/sbin/start-slave.sh -h <slave-hostname> <spark master uri>
```
