    alluxio.worker.allocator.class=alluxio.worker.block.allocator.MaxFreeAllocator
    alluxio.worker.evictor.class=alluxio.worker.block.evictor.LRUEvictor
