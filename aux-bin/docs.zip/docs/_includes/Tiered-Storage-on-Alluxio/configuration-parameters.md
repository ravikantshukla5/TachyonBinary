    alluxio.worker.tieredstore.levels
    alluxio.worker.tieredstore.level{x}.alias
    alluxio.worker.tieredstore.level{x}.dirs.quota
    alluxio.worker.tieredstore.level{x}.dirs.path
    alluxio.worker.tieredstore.level{x}.reserved.ratio 
