```bash
$ bin/alluxio-fuse.sh stat
```
