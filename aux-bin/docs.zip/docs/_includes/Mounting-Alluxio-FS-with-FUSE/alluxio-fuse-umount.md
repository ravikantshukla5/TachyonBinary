```bash
$ bin/alluxio-fuse.sh umount
```
