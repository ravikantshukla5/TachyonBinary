```bash
$ bin/alluxio-fuse.sh mount <mount_point>
```
