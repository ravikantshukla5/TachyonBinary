```java
FileSystem fs = FileSystem.Factory.get();
```
