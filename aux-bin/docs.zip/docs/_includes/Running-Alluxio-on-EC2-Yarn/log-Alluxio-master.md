```
15/10/22 21:50:23 INFO : Launching container container_1445550205172_0001_01_000002 for Alluxio master on AlluxioMaster:8042 with master command: [/alluxio/integration/bin/alluxio-master-yarn.sh 1><LOG_DIR>/stdout 2><LOG_DIR>/stderr ]
```
