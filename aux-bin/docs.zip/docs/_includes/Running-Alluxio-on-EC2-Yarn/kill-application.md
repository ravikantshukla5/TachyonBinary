```bash
$ /hadoop/bin/yarn application -kill application_1445469376652_0002
```
