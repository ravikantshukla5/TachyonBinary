```bash
$ mvn clean install -Dhadoop.version=2.4.1 -Pyarn
```
