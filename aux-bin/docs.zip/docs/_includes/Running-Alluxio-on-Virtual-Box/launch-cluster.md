```bash
./create <number of machines> vb
```
