```bash
$ ./bin/alluxio fs mount s3n://data-bucket/ /s3/data
```
