```bash
$ ./bin/alluxio fs location /data/2015/logs-1.txt
```
