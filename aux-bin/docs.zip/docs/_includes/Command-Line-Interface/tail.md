```bash
$ ./bin/alluxio fs tail /output/part-00000
```
