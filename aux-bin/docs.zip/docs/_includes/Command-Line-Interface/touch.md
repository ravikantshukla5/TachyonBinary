```bash
$ ./bin/alluxio fs touch /data/yesterday/_DONE_
```
