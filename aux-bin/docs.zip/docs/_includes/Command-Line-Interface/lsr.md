```bash
$ ./bin/alluxio fs lsr /users/
```
