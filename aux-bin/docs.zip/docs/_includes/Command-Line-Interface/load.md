```bash
$ ./bin/alluxio fs load /data/today
```
