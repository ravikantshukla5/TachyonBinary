```bash
$ ./bin/alluxio fs count /data/2014
```
