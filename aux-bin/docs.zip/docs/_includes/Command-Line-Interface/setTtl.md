```bash
$ ./bin/alluxio fs setTtl /data/good-for-one-day 86400000
```
