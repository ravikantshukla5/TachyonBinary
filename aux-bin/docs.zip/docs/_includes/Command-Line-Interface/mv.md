```bash
$ ./bin/alluxio fs mv /data/2014 /data/archives/2014
```
