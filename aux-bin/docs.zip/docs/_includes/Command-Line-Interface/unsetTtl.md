```bash
$ ./bin/alluxio fs unsetTtl /data/yesterday/data-not-yet-analyzed
```
