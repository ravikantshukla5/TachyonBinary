```bash
$ ./bin/alluxio fs getCapacityBytes
```
