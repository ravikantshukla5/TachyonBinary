```bash
$ ./bin/alluxio fs cat /output/part-00000
```
