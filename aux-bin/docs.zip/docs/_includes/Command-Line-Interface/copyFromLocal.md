```bash
$ ./bin/alluxio fs copyFromLocal /local/data /input
```
