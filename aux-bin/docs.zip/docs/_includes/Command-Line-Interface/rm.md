```bash
$ ./bin/alluxio fs rm /data/2014*
```
