```bash
$ ./bin/alluxio fs rm /tmp/unused-file
```
