```bash
$ ./bin/alluxio fs unmount /s3/data
```
