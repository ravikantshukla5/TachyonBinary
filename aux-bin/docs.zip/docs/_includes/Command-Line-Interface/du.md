```bash
$ ./bin/alluxio fs du /\\*
```
