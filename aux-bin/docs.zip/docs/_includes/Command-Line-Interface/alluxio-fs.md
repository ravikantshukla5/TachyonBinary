```bash
$ ./bin/alluxio fs
```
