```bash
$ ./bin/alluxio fs free /unused/data
```
