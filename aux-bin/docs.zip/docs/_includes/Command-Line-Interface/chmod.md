```bash
$ ./bin/alluxio fs chmod 755 /input/file1
```
