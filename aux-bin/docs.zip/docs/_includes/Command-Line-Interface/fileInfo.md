```bash
$ ./bin/alluxio fs fileInfo /data/2015/logs-1.txt
```
