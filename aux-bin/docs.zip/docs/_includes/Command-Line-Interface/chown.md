```bash
$ ./bin/alluxio fs chown alluxio-user /input/file1
```
