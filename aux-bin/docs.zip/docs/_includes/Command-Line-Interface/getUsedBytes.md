```bash
$ ./bin/alluxio fs getUsedBytes
```
