```bash
$ ./bin/alluxio fs chgrpr alluxio-group-new /input/directory1
```
