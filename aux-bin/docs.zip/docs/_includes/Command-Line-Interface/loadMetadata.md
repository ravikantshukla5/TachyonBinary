```bash
$ ./bin/alluxio fs loadMetadata /hdfs/data/2015/logs-1.txt
```
