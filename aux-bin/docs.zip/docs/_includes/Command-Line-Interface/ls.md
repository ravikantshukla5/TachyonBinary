```bash
$ ./bin/alluxio fs ls /users/alice/
```
