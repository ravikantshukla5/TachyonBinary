```bash
$ ./bin/alluxio fs chmodr 755 /input/directory1
```
