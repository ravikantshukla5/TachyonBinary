```bash
$ ./bin/alluxio fs report /tmp/lineage-file
```
