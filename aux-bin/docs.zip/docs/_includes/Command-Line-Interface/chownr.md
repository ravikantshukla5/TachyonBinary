```bash
$ ./bin/alluxio fs chownr alluxio-user /input/directory1
```
