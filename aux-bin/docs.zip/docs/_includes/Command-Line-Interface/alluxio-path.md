    alluxio://<master node address>:<master node port>/<path>
