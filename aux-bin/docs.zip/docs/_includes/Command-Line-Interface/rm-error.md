```
rm takes 1 arguments,  not 21
```
