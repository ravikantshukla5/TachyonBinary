```bash
$ ./bin/alluxio fs chgrp alluxio-group-new /input/file1
```
