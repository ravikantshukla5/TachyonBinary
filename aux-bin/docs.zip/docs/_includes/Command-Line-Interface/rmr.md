```bash
$ ./bin/alluxio fs rmr /tmp/tests
```
