```bash
$ ./bin/alluxio fs cat /\\*
```
