```bash
$ ./bin/alluxio fs unpin /data/yesterday/join-table
```
