```bash
$ ./bin/alluxio fs persist /tmp/experimental-logs-2.txt
```
