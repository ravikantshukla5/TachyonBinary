```bash
$ ./bin/alluxio fs pin /data/today
```
