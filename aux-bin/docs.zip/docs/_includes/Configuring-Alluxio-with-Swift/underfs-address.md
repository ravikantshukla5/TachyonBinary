```bash
export ALLUXIO_UNDERFS_ADDRESS=swift://<swift-containter>
```
