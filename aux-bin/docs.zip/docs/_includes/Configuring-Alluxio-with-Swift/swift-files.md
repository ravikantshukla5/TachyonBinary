    swift://<SWIFT CONTAINER>/alluxio/data/default_tests_files/BasicFile_STORE_SYNC_PERSIST
