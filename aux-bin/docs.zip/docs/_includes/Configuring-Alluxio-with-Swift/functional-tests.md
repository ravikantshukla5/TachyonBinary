```bash
$ mvn test -PswiftTest -pl tests
```
