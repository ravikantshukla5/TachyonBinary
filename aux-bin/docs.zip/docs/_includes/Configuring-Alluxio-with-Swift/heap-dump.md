  <argLine>-XX:+HeapDumpOnOutOfMemoryError 
    -XX:HeapDumpPath=/location/dump</argLine>
