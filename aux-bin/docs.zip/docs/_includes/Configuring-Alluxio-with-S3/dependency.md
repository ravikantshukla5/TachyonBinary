```xml
<dependency>
  <groupId>org.alluxio</groupId>
  <artifactId>alluxio-core-client</artifactId>
  <version>{{site.ALLUXIO_RELEASED_VERSION}}</version>
</dependency>
```
