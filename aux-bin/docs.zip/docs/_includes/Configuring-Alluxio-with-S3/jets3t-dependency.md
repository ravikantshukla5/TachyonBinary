```xml
<dependency>
  <groupId>net.java.dev.jets3t</groupId>
  <artifactId>jets3t</artifactId>
  <version>0.9.0</version>
  <exclusions>
    <exclusion>
      <groupId>commons-codec</groupId>
      <artifactId>commons-codec</artifactId>
      <!-- <version>1.3</version> -->
    </exclusion>
  </exclusions>
</dependency>
```
