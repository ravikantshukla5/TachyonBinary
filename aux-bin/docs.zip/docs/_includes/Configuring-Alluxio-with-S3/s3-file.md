    S3_BUCKET/S3_DIRECTORY/alluxio/data/default_tests_files/BasicFile_STORE_SYNC_PERSIST
