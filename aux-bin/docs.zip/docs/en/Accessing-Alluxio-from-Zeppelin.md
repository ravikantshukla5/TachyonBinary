---
layout: global
title: Accessing Alluxio From Zeppelin
nickname: Apache Zeppelin
group: Frameworks
priority: 4
---

[Apache Zeppelin](http://http://zeppelin-project.org/) is a web-based notebook that enables 
interactive data analytics. An older version of Alluxio (Tachyon 0.8.2) has been
[integrated](https://github.com/apache/incubator-zeppelin/blob/master/docs/interpreter/alluxio.md) 
with Zeppelin and we will soon update the integration to work with the latest version of Alluxio.
