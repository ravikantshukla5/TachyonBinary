/*
 * The Alluxio Open Foundation licenses this work under the Apache License, version 2.0
 * (the “License”). You may not use this work except in compliance with the License, which is
 * available at www.apache.org/licenses/LICENSE-2.0
 *
 * This software is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied, as more fully set forth in the License.
 *
 * See the NOTICE file distributed with this work for information regarding copyright ownership.
 */

package alluxio.wire;

import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;

import java.util.Random;

public class WorkerNetAddressTest {

  @Test
  public void jsonTest() throws Exception {
    WorkerNetAddress workerNetAddress = createRandom();
    ObjectMapper mapper = new ObjectMapper();
    WorkerNetAddress other =
        mapper.readValue(mapper.writeValueAsBytes(workerNetAddress), WorkerNetAddress.class);
    checkEquality(workerNetAddress, other);
  }

  @Test
  public void thriftTest() {
    WorkerNetAddress workerNetAddress = createRandom();
    WorkerNetAddress other = ThriftUtils.fromThrift(ThriftUtils.toThrift(workerNetAddress));
    checkEquality(workerNetAddress, other);
  }

  public void checkEquality(WorkerNetAddress a, WorkerNetAddress b) {
    Assert.assertEquals(a.getHost(), b.getHost());
    Assert.assertEquals(a.getRpcPort(), b.getRpcPort());
    Assert.assertEquals(a.getDataPort(), b.getDataPort());
    Assert.assertEquals(a.getWebPort(), b.getWebPort());
    Assert.assertEquals(a, b);
  }

  public static WorkerNetAddress createRandom() {
    WorkerNetAddress result = new WorkerNetAddress();
    Random random = new Random();

    byte[] bytes = new byte[5];
    random.nextBytes(bytes);
    String host = new String(bytes);
    int rpcPort = random.nextInt();
    int dataPort = random.nextInt();
    int webPort = random.nextInt();

    result.setHost(host);
    result.setRpcPort(rpcPort);
    result.setDataPort(dataPort);
    result.setWebPort(webPort);

    return result;
  }
}
